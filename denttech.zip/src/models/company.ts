export type Payment = {
  id: number;
  amount?: string,
  paymentDate?: string,
  paymentNumber?: string,
  reference?: string,
}
