import Applayout from "@/components/layout/Applayout";

export default function Dashbord() {

    return (
        <>
            <Applayout>
                Dashbord Page
            </Applayout>
        </>
    );
}