export type Item = {
  id: number;
  name: string;
  description: string;
  price1: number;
  price2: number;
  price3: number;
  price4: number;
};
