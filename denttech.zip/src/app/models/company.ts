export type Company = {
  name: string;
  balance: string;
  credit: string;
  debit: string;
  status: string;
  email: string;
  mobile: string;

};
