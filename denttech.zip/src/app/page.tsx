import Image from 'next/image'
import Dashbord from './dashbord/page'

export default function Home() {
  return (
    <Dashbord />
  )
}
