
type authStateType = {
    token: string | null,
}
const initialState: authStateType = {
    token: null,

};
export { initialState };
export type { authStateType };
