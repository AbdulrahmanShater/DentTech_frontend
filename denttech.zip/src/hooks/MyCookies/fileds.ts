enum MY_COOKIES_FILEDS {
    TOKEN = "token",
    // USER = "user",
}
export default MY_COOKIES_FILEDS;